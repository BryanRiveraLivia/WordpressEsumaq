<?php
/*
 * Template Name: Página Nosotros
 */

// Llama al encabezado
get_header();
?>

<!-- Aquí puedes escribir el contenido único de tu página "Nosotros" -->
<div class="contenido-nosotros">
    <h1>Bienvenidos a la Página de Nosotros</h1>
    <p>Este es el contenido de la página "Nosotros".</p>
</div>

<?php
// Llama al pie de página
get_footer();
?>