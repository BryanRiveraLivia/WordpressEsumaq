<?php
get_header();
?>
<h1>Página no encontrada</h1>
<p>Lo sentimos, pero la página que estás buscando no existe.</p>
<a href="<?php echo home_url(); ?>">Volver al inicio</a>
<?php
get_footer();
?>
